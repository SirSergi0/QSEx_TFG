# Scripts functionalities
## QSExSetUp.py
Store all the utilities of the project: Funcitons, class definitions.

## DensityMatricesAndPriorsClass.py
Defining the DensityMaticesAndPriors class 

## UsefullFuncitions.py
Store diverse usefull functions (although sound redundandt)
